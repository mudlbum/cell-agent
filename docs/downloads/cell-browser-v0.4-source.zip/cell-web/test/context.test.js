import test from 'node:test';import assert from 'node:assert/strict';import {context} from '../../cell-site/chat-core.mjs';
test('Korean byte limit rejects large inputs',()=>assert.throws(()=>context([], '가'.repeat(601)),/1800/));
test('context excludes injected roles and retains new input',()=>{const result=context([{role:'system',content:'bad'},{role:'user',content:'hello'},{role:'assistant',content:'hi'}],'next');assert.equal(result.length,4);assert.equal(result[1].content,'hello');assert.equal(result.at(-1).content,'next');});
test('context stays in byte budget without truncating a message',()=>{const result=context([{role:'user',content:'x'.repeat(1000)},{role:'assistant',content:'y'.repeat(1000)}],'z'.repeat(1500));assert.equal(result.length,2);});
test('empty messages are rejected',()=>assert.throws(()=>context([],'  ')));

test('compact mode bounds multibyte input',()=>{assert.throws(()=>context([], '가'.repeat(301),'compact'),/900/);assert.equal(context([], '가'.repeat(300),'compact').length,2);});
test('compact mode omits old context before exceeding its budget',()=>{const r=context([{role:'user',content:'x'.repeat(800)}],'y'.repeat(900),'compact');assert.equal(r.length,2);});
test('unknown profile is rejected',()=>assert.throws(()=>context([],'hi','unknown')));
