import {CreateMLCEngine, deleteModelAllInfoInCache} from '@mlc-ai/web-llm';
let engine, busy=false, outputLimit=256;
const profiles={compact:{context_window_size:2048},balanced:{context_window_size:4096}};
self.onmessage=async({data})=>{
 if(busy)return; busy=true;
 try{
  if(data.type==='load'){
   if(!profiles[data.profile])throw Error('지원하지 않는 실행 설정입니다.');
   outputLimit=data.profile==='compact'?256:512;
   engine=await CreateMLCEngine(data.model,{initProgressCallback:r=>postMessage({type:'progress',text:r.text,progress:r.progress})},profiles[data.profile]);
   postMessage({type:'ready'});
  }else if(data.type==='clear'){
   for(const id of data.models)await deleteModelAllInfoInCache(id);
   postMessage({type:'cleared'});
  }else if(data.type==='chat'){
   if(!engine)throw Error('모델을 먼저 불러오세요.');
   const stream=await engine.chat.completions.create({messages:data.messages,stream:true,max_tokens:outputLimit,temperature:0.3,extra_body:{enable_thinking:false}});
   for await(const chunk of stream){const text=chunk.choices[0]?.delta?.content;if(text)postMessage({type:'token',text});}
   postMessage({type:'done'});
  }
 }catch(e){postMessage({type:'error',text:String(e.message||e)});}finally{busy=false;}
};
